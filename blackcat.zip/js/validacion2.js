window.onload = function() {
    // Validar formulario de inicio de sesión
    document.getElementById("formularioInicioSesion").addEventListener("submit", function(event) {
        event.preventDefault(); // Evitar que el formulario se envíe automáticamente
        validarFormularioInicioSesion();
    });

    // Validar formulario de inicio de sesión
    function validarFormularioInicioSesion() {
        // Obtener los valores de los campos del formulario de inicio de sesión
        var correo = document.querySelector('#bodySesion input[name="correo"]').value.trim();
        var contrasena = document.querySelector('#bodySesion input[name="contrasena"]').value.trim();

        // Validar el correo electrónico
        if (!validarCorreoElectronico(correo)) {
            alert("Por favor, introduce un correo electrónico válido.");
            return;
        }

        // Validar que la contraseña no esté vacía
        if (contrasena === "") {
            alert("Por favor, introduce tu contraseña.");
            return;
        }

        // Si todos los campos son válidos, enviar el formulario
        alert("¡Formulario de inicio de sesión enviado con éxito!");
        // Aquí puedes hacer algo con el formulario, como enviarlo a través de AJAX o simplemente enviarlo normalmente.
    }

    // Función para validar un correo electrónico
    function validarCorreoElectronico(correo) {
        // Expresión regular para validar el formato del correo electrónico
        var correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return correoRegex.test(correo);
    }
};
