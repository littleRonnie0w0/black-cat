document.addEventListener('DOMContentLoaded', function() {
  let iconCart = document.querySelector('.icon-cart');
  let closeCart = document.querySelector('.close');
  let cartTab = document.querySelector('.cartTab');
  let listProductHTML = document.querySelector('.listProduct')
  let listCartHTML = document.querySelector('.listCart');
  let iconCartSpan = document.querySelector('.icon-cart span');
  let listProducts=[
    {
        "id": 1,
        "name": "Body",
        "price": 8000,
        "image": "../imagenes/imagen1.jpg"
    },
    {
        "id": 2,
        "name": "Boxer gotico",
        "price": 6000,
        "image": "../imagenes/imagen2.jpg"
    },
    {
        "id": 3,
        "name": "Boxer de malla",
        "price": 6000,
        "image": "../imagenes/imagen3.jpg"
    },
    {
        "id": 4,
        "name": "Body rojo",
        "price": 8000,
        "image": "../imagenes/imagen4.jpg"
    },
    {
        "id": 5,
        "name": "Bragas con tirantes",
        "price": 6000,
        "image": "../imagenes/imagen9.jpg"
    },
    {
        "id": 6,
        "name": "Brasier dark gotico",
        "price": 5000,
        "image": "../imagenes/imagen6.jpg"
    },
    {
        "id": 7,
        "name": "Body negro escotado",
        "price": 8000,
        "image": "../imagenes/imagen7.jpg"
    },
    {
        "id": 8,
        "name": "Bragas con tirantes",
        "price": 6000,
        "image": "../imagenes/imagen8.jpg"
    },
    {
      "id": 9,
      "name": "Brasier dark",
      "price": 6000,
      "image": "../imagenes/imagen11.jpg"
  },
  {
    "id": 10,
    "name": "bragas negras con tirantes",
    "price": 6000,
    "image": "../imagenes/imagen10.jpg"
},
{
  "id": 11,
  "name": "boxer kawai",
  "price": 6000,
  "image": "../imagenes/imagen5.jpg"
},
{
  "id": 12,
  "name": "Brasier rojo intrenso",
  "price": 6000,
  "image": "../imagenes/imagen12.jpg"
}

];

  // let listProducts = [];
  let carts= [];

  let carrito = [];

  iconCart.addEventListener('click', () => {
    cartTab.classList.toggle('showCart');
  });

  closeCart.addEventListener('click', () =>{
    cartTab.classList.toggle('showCart');
  })
/*para añadir los demas:  no funciona*/ 
  const addDataToHTML = () =>{
    listProductHTML.innerHTML = '';
    if(listProducts.length > 0){
        listProducts.forEach(product =>{
            let newProduct = document.createElement('div');
            newProduct.classList.add('item');
            newProduct.dataset.id = product.id;
            newProduct.innerHTML = `
                <img src="${product.image}" alt="">
                <h2>${product.name}</h2>
                <div class="price">$${product.price}</div>
                <button class="addCart">añadir al carro</button>`;
            listProductHTML.appendChild(newProduct);
        })
    }
}
/*para añadir al cart: no funciona*/ 
listProductHTML.addEventListener('click',(event)=> {
  let positionClick = event.target;
  if (positionClick.classList.contains('addCart')) {
    let product_id = positionClick.parentElement.dataset.id;
    
addToCart(product_id);


  }
})

const addToCart = (product_id) => {
  let positionItemCart = carrito.findIndex((value) => value.product_id === product_id);
  console.log("positionThisProductInCart: "+positionItemCart)
  if(carts.length <= 0){
  carrito = [{
    product_id : product_id,
    quantity: 1
  }]
 }else if(positionItemCart < 0){
  carrito.push({
    product_id: product_id,
    quantity: 1
  });
}else{
  carrito[positionItemCart].quantity = carrito[positionItemCart].quantity +1;
}

 addCartToHTML();
 addcartToMemory();
}
/*no funciona*/
const addcartToMemory = () => {
  localStorage.setItem('cart', JSON.stringify(carts));
}
const addCartToHTML = () => {
  listCartHTML.innerHTML = '';
  let totalQuantity = 0;
  if (carts.length > 0) {
    
    carrito.forEach(cart => {
      console.log(cart);
      totalQuantity = totalQuantity + cart.quantity;
      let positionProduct = listProducts.findIndex((value) => value.id == cart.product_id); // Corregido
      console.log(listProducts);
      let info = listProducts[positionProduct];

      
      let newCart = document.createElement('div');
      newCart.classList.add('item');
      newCart.dataset.id = cart.product_id; 
      newCart.innerHTML = `
        <div class="image">
          <img src="${info.image}" alt="">
        </div>
        <div class="name">${info.name}</div> 
        <div class="price">$${info.price * cart.quantity}</div> 
        <div class="quantity">
          <span><div class="minus">&lt;</div></span> <!-- Corregido -->
          <span>${cart.quantity}</span>
          <span><div class="plus">&gt;</div></span> 
        </div>`;
      listCartHTML.appendChild(newCart);
    });
  }
  iconCartSpan.innerHTML = totalQuantity;
};

listCartHTML.addEventListener('click', (event) => {
  let positionClick = event.target;
  if (positionClick.classList.contains('minus') || positionClick.classList.contains('plus')) {
    let product_id = positionClick.parentElement.parentElement.parentElement.dataset.id;
    let type = 'minus';
    console.log(positionClick.parentElement.parentElement.parentElement);
    
    if (positionClick.classList.contains('plus')) {
      type = 'plus';
    }
    changeQuantity(product_id, type);
  }
});

const changeQuantity = (product_id, type) => {
  
  let positionItemCart = carrito.findIndex((value) => value.product_id === product_id);
  if (positionItemCart >= 0) {
    switch (type) {
      case 'plus':
        carrito[positionItemCart].quantity = carrito[positionItemCart].quantity + 1;
        break;
      default:
        let valueChange = carrito[positionItemCart].quantity - 1;
        if (valueChange > 0) {
          carrito[positionItemCart].quantity = valueChange;
        } else {
          carrito.splice(positionItemCart, 1);
        }
        break;
    }
    addcartToMemory();
    addCartToHTML();
  }
};
  const initApp = () => {
    
      carts = listProducts;
      addDataToHTML();

      /*get cart from memory (no funciona nada pipipi) */
      if(localStorage.getItem('cart')){
        carts = JSON.parse(localStorage.getItem('cart'));
        console.log(carts);
        addCartToHTML();
      }
    }
  initApp();
});


