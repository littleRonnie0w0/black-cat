document.addEventListener('DOMContentLoaded', function() {
    let iconCart = document.querySelector('.icon-cart');
    let closeCart = document.querySelector('.close');
    let cartTab = document.querySelector('.cartTab');
    let listProductHTML = document.querySelector('.listProduct')
    let listCartHTML = document.querySelector('.listCart');
    let iconCartSpan = document.querySelector('.icon-cart span');
  
    let listProducts = [];
    let carts= [];
  
    let carrito = [];

    

    iconCart.addEventListener('click', () => {
      cartTab.classList.toggle('showCart');
    });
  
    closeCart.addEventListener('click', () =>{
      cartTab.classList.toggle('showCart');
    })
   
    const addDataToHTML = () =>{
      listProductHTML.innerHTML = '';
      if(listProducts.length > 0){
          listProducts.forEach(product =>{
              let newProduct = document.createElement('div');
              newProduct.classList.add('item');
              newProduct.dataset.id = product.id;
              newProduct.innerHTML = `
                  <img src="${product.image}" alt="">
                  <h2>${product.name}</h2>
                  <div class="price">$${product.price}</div>
                  <button class="addCart">añadir al carro</button>`;
              listProductHTML.appendChild(newProduct);
          })
      }
  }

  listProductHTML.addEventListener('click',(event)=> {
    let positionClick = event.target;
    if (positionClick.classList.contains('addCart')) {
      let product_id = positionClick.parentElement.dataset.id;
  
      
  addToCart(product_id);
  
  
    }
  })
  
  const addToCart = (product_id) => {
    let positionThisProductInCart = carts.findIndex((value) => value.product_id === product_id);
   if(carts.length <= 0){
    carrito = [{
      product_id : product_id,
      quantity: 1
    }]
   }else if(positionThisProductInCart < 0){
    carrito.push({
      product_id: product_id,
      quantity: 1
    });
  }else{
    carrito[positionThisProductInCart].quantity = carrito[positionThisProductInCart].quantity +1;
  }
   addCartToHTML();
   addcartToMemory();
  }

  const addcartToMemory = () => {
    localStorage.setItem('cart', JSON.stringify(carts));
  }
  const addCartToHTML = () => {
    listCartHTML.innerHTML = '';
    let totalQuantity = 0;
    if (carts.length > 0) {
      
      carrito.forEach(cart => {
        console.log(cart);
        totalQuantity = totalQuantity + cart.quantity;
        let positionProduct = listProducts.findIndex((value) => value.id == cart.product_id); // Corregido
        console.log(listProducts);
        let info = listProducts[positionProduct];
  
        
        let newCart = document.createElement('div');
        newCart.classList.add('item');
        newCart.dataset.id = cart.product_id; 
        newCart.innerHTML = `
          <div class="image">
            <img src="${info.image}" alt="">
          </div>
          <div class="name">${info.name}</div> 
          <div class="price">$${info.price * cart.quantity}</div> 
          <div class="quantity">
            <span><div class="minus">&lt;</div></span> <!-- Corregido -->
            <span>${cart.quantity}</span>
            <span><div class="plus">&gt;</div></span> 
          </div>`;
        listCartHTML.appendChild(newCart);
      });
    }
    iconCartSpan.innerHTML = totalQuantity;
  };
  
  listCartHTML.addEventListener('click', (event) => {
    let positionClick = event.target;
    if (positionClick.classList.contains('minus') || positionClick.classList.contains('plus')) {
      let product_id = positionClick.parentElement.parentElement.parentElement.dataset.id;
      let type = 'minus';
      console.log(positionClick.parentElement.parentElement.parentElement);
      
      if (positionClick.classList.contains('plus')) {
        type = 'plus';
      }
      changeQuantity(product_id, type);
    }
  });
  
  const changeQuantity = (product_id, type) => {
    
    let positionItemCart = carrito.findIndex((value) => value.product_id === product_id);
    if (positionItemCart >= 0) {
      switch (type) {
        case 'plus':
          carrito[positionItemCart].quantity = carrito[positionItemCart].quantity + 1;
          break;
        default:
          let valueChange = carrito[positionItemCart].quantity - 1;
          if (valueChange > 0) {
            carrito[positionItemCart].quantity = valueChange;
          } else {
            carrito.splice(positionItemCart, 1);
          }
          break;
      }
      addcartToMemory();
      addCartToHTML();
    }
  };
    const initApp = () => {
      fetch('/products2.json')
      .then(Response => Response.json())
      .then( data => {
        listProducts = data
        carts = listProducts;
        addDataToHTML();
  
        /*get cart from memory */
        if(localStorage.getItem('cart')){
          carts = JSON.parse(localStorage.getItem('cart'));
          console.log(carts);
          addCartToHTML();
        }
      })
    }
    initApp();
  });


