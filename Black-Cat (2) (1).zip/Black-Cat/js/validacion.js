window.onload = function() {
    // Validar formulario de registro
    document.getElementById("formularioRegistro").addEventListener("submit", function(event) {
        event.preventDefault(); // Evitar que el formulario se envíe automáticamente
        validarFormularioRegistro();
    });

    // Validar formulario de registro
    function validarFormularioRegistro() {
        // Expresiones regulares para validar los campos
        var letrasRegex = /^[A-Za-z]+$/;
        var alfanumericoRegex = /^[0-9a-zA-Z]+$/;
        var numericoRegex = /^[0-9]+$/;

        // Obtener los valores de los campos del formulario de registro
        var apodo = document.querySelector('#cuadroSesion2 input[name="apodo"]').value.trim();
        var nombre = document.querySelector('#cuadroSesion2 input[name="nombre"]').value.trim();
        var apellido = document.querySelector('#cuadroSesion2 input[name="apellido"]').value.trim();
        var direccion = document.querySelector('#cuadroSesion2 input[name="direccion"]').value.trim();
        var celular = document.querySelector('#cuadroSesion2 input[name="celular"]').value.trim();
        var contrasena = document.querySelector('#cuadroSesion2 input[name="contrasena"]').value.trim();

        // Validar cada campo
        if (!letrasRegex.test(apodo)) {
            alert("Por favor, introduce un apodo válido (solo letras).");
            return;
        }
        if (!letrasRegex.test(nombre)) {
            alert("Por favor, introduce un nombre válido (solo letras).");
            return;
        }
        if (!letrasRegex.test(apellido)) {
            alert("Por favor, introduce un apellido válido (solo letras).");
            return;
        }
        if (!alfanumericoRegex.test(direccion)) {
            alert("Por favor, introduce una dirección válida (solo caracteres alfanuméricos).");
            return;
        }
        if (!numericoRegex.test(celular)) {
            alert("Por favor, introduce un número de celular válido (solo dígitos numéricos).");
            return;
        }
        if (!alfanumericoRegex.test(contrasena)) {
            alert("Por favor, introduce una contraseña válida (solo caracteres alfanuméricos).");
            return;
        }

        // Si todos los campos son válidos, enviar el formulario
        alert("¡Formulario de registro enviado con éxito!");
        // Aquí puedes hacer algo con el formulario, como enviarlo a través de AJAX o simplemente enviarlo normalmente.
    }
};
