async function getProductos() {
    let response = await fetch("https://api.escuelajs.co/api/v1/products/?categoryId=2");
    let items = await response.json();
  
    let response2 = await fetch("https://mindicador.cl/api");
    let valores = await response2.json();
  
    let dolar = valores.dolar.valor;
  
    let productos = document.querySelector("#productos");
  
    for (let item of items) {
      let producto = document.createElement("div");
      producto.classList.add("producto");
  
      let urlImagen = item.images[0]; // Suponiendo que item.images[0] contiene la URL de la imagen
  
      let imagen = document.createElement("div");
      imagen.style.backgroundImage = `url(${urlImagen})`;
      producto.appendChild(imagen);
  
      let nombre = document.createElement("div");
      nombre.classList.add("nombre");
      nombre.innerHTML = item.title;
      producto.appendChild(nombre);
  
      let precio = document.createElement("div");
      precio.classList.add("precio");
      precio.innerHTML = "$" + item.price + " (" + (item.price / dolar).toFixed(2) + "usd)";
      producto.appendChild(precio);
  
      productos.appendChild(producto);
    }
  }
  
  getProductos();
  